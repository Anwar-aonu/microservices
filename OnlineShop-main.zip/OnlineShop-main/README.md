# OnlineShop

https://github.com/machindravagare/config-repo/blob/main/config.properties



![Whiteboard 4 -01](https://user-images.githubusercontent.com/104611736/167536961-4105a9bb-99cc-4b3a-8326-c7dff4584b11.png)
<img width="710" alt="Screenshot 2022-05-10 at 9 37 37 AM" src="https://user-images.githubusercontent.com/104611736/167540749-c0de1b34-c10a-436c-b4ec-afbdcad478d6.png">


Contributors:
Amandeep,
Machindra,
Pooja,
Samiksha
